// Get the booking form from the HTML page
const bookingForm = document.getElementById("bookingForm");

// Check if the booking form exists on the current page
if (bookingForm) {

    // Run this code when the user submits the form
    bookingForm.addEventListener("submit", function(event) {

        // Prevent the page from refreshing
        event.preventDefault();

        // Display a confirmation message
        alert("Thank you! Your booking enquiry has been submitted.");

        // Clear the form after submission
        bookingForm.reset();
    });
}