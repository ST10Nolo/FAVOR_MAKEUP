# Favour_Makeup
A responsive website developed for Favour Makeup, beauty business based in Sandton.
